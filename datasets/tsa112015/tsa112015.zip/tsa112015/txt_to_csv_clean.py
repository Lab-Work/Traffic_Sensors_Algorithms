__author__ = 'wbarbour1'

import csv
import os
from pir_convert import *
import time
import traceback

# the best way to run this script is to make a copy and move it to the root directory of the data
# verify the directory prefix is correct
# verify the file extensions are correct and there are no extraneous files in the directories

# ** needs to be accompanied by pir_convert.py file in same directory


translate_list = []
# get txt_to_csv_clean.py directory path (current directory)
dir_stub = os.path.dirname(os.path.realpath(__file__))
directories = []
# gets list of folders/directories in current directory with prefix "serialPIR"
print "Input file directories:"
for direc in os.listdir(dir_stub):
    if direc.__contains__('serialPIR'):
        print direc
        directories.append(direc)
# explore each directory for files ending with extension '.txt' or '.asc'
print "Input files:"
for direc in directories:
    for f_name in os.listdir(dir_stub + '/' + direc):
        print direc + '/' + f_name
        if f_name[-4:] == '.txt' or f_name[-4:] == '.asc':
            # add to list of files to translate, along with directory prefix
            translate_list.append(direc + '/' + f_name)


for txt_file in translate_list:
    print "Working on", txt_file, txt_file[0]

    # output file name gets appended with '_output' and gets new '.csv' extension
    trial_fname = txt_file
    output_fname = trial_fname[0:-4] + '_output.csv'
    print "output file: ", output_fname

    # open input file and output file
    trans_file = open(trial_fname, 'r')
    csv_file = open(output_fname, 'w')
    csv_writer = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_NONE)

    # sample header lines until a PIR string is found
    # length of first valid line (>80 chars) determines the size of the frame
    # constructs a PIR converter based on frame (PIR3 = 4x48 frame, PIR1x16 = 1x16 frame)
    # this isn't a very robust way to do this but I just needed to get it working quickly
    # ** a better way to do this might be to run try: parse as 4x48, try: parse as 1x16
    # ** and move forward with the method that doesn't fail
    while True:
        t = trans_file.readline()
        if len(t) > 800:
            print "Length >800, continue."
            converter = PIR3_converter()
            break
        elif len(t) > 150:
            print "File type is 4x48; converter is PIR3_converter()."
            converter = PIR3_converter()
            break
        elif len(t) > 80:
            print "File type is 1x16; converter is PIR1x16_converter()."
            converter = PIR1x16_converter()
            break
        else:
            print "Length <=80, continue.", t
            continue

    # split timestamp and PIR line
    # send PIR line to converter for hex --> temperature
    for line in trans_file:
        l = line.split(',')
        csv_line = []
        try:
            csv_line = [l[0]] + converter.convert(l[1])
        except:
            # common cause for translation failure is extra blank lines in .txt data
            # output suppressed for this behavior, but useful for debugging if needed
            pass
            #print "Line pass.", l
            #print traceback.print_exc()

        csv_writer.writerow(csv_line)

    # close input file and output file
    trans_file.close()
    csv_file.close()
    print csv_file.name, " complete. Pausing for 1 seconds."
    # running through files to quickly causes read errors for unknown reason
    time.sleep(1)
