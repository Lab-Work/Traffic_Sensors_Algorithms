import os

dir_stub = os.path.dirname(os.path.realpath(__file__))
new_dir_path = "/serialPIR_" + "dir_test"
os.mkdir(dir_stub + new_dir_path)