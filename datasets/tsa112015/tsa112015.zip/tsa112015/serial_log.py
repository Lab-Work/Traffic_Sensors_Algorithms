import serial
import os
from datetime import datetime as dt
from threading import *
import time


class laptop_log:

    def __init__(self, save_interval=5.0):
        """
        :param save_interval: interval in MINUTES for file to run before it is closed
        :return:
        """
        dir_stub = os.path.dirname(os.path.realpath(__file__))
        self.new_dir_path = "serialPIR_" + dt.now().strftime("%Y_%m_%d__%H_%M_%S")
        os.mkdir(dir_stub + "/" + self.new_dir_path)

        print "Attempting to connect to USB serial"
        self.ser = serial.Serial('/dev/ttyUSB0', 230400)
        print "Connection successful"
        self.save_int = save_interval
        self.event_pir = Event()
        self.event_pir.set()
        self.event_pir.clear()
        self.thread_pir = Thread(name='pir', target=self.record_pir)
        print "Initiating threads."
        print "Thread names:"
        print self.thread_pir.getName()
        self.thread_pir.start()
        print "Running threads: ", enumerate()
        print "\nInitialization complete.\n"

    def record_pir(self):
        while True:
            while not self.event_pir.isSet():
                time.sleep(0.25)
            r_p = self.ser.readline()
            self.f.write(dt.now().strftime("%H_%M_%S_%f") + "," + str(r_p) + '\n')

    def start_new_file(self):
        print "Starting new file."
        f_name = self.new_dir_path + '/logPIR_'
        file_time = dt.now().strftime("%Y_%m_%d__%H_%M_%S")
        f_name += file_time
        f_name += '.txt'
        print f_name
        self.f = open(f_name, 'a')
        # self.f.write("PIR sensor data file!\n")
        # self.f.write(file_time)
        # self.f.write("\n")
        # self.f.write("Line begins with timestamp %HOUR_%MINUTE_%SECOND_%MICROSECOND indicating time line written.\n")
        # self.f.write("PIR string contains raw serial string read on USB serial port.\n")
        # self.f.write("\n")
        # self.f.write("\n")

    def start_record(self):
        print "Running threads:", enumerate()
        self.event_pir.set()

    def stop_record(self):
        self.event_pir.clear()
        # give threads time to stop since read/write operations take time and f.close executes quickly
        time.sleep(0.5)
        self.f.write("End of file!")
        self.f.close()

LL = laptop_log(save_interval=5.0)
while True:
    LL.start_new_file()
    LL.start_record()
    print "Sleeping for file interval time"
    time.sleep(LL.save_int * 60)
    LL.stop_record()
