__author__ = 'wbarbour1'

import csv
import os
from pir_convert import *
import time

converter = PIR3_converter()

translate_list = []
for f_name in os.listdir('/Users/wbarbour1/Documents/Dropbox/CEE/PIR Array/data_09_03/tsa0903'):
    if f_name[0:6] == 'sensor' and f_name[-4:] == '.txt':
        translate_list.append(f_name)

print translate_list

skip_flag = False
for txt_file in translate_list:

    trial_fname = txt_file
    output_fname = 'csv_' + trial_fname[0:-4] + '.csv'
    print "output file: ", output_fname
    skip_line_counter = 1
    trans_file = open(trial_fname, 'r')
    csv_file = open(output_fname, 'w')
    csv_writer = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_NONE)

    for line in trans_file:
        if skip_line_counter > 8:
            parse = line.split(',')
            csv_line = []
            sensor = ''
            ts = parse[0]
            csv_line.append(ts)
            try:
                sensor = parse[1]
            except:
                print "line does not correspond to IMU or PIR format"
                print parse

            if sensor == '_IMU+Uson_':
                csv_line.append(sensor[1:4])
                csv_line.append(parse[2][2:])
                csv_line.append(parse[3][1:])
                csv_line.append(parse[4][1:-1])
                csv_line.append(parse[5][2:])
                csv_line.append(parse[6][1:])
                csv_line.append(parse[7][1:-1])
                csv_line.append(parse[8][1:-2])
                #print csv_line

            else:
                if sensor == '_PIR_':
                    csv_line.append(sensor[1:4])
                    #print parse[2]
                    if parse[2][:-1] == '-1' or len(parse[2])<800:
                        csv_line.append(-1)
                    else:
                        #print parse[2][2:-2]
                        csv_line += converter.convert(parse[2][2:-2])
                        #csv_line.append(PIR3_converter.convert(parse[3]))
                else:
                    print "second index read error"
                    skip_flag = True
                    
            if not skip_flag:
                csv_writer.writerow(csv_line)
            else:
                skip_flag = False
        else:
            skip_line_counter += 1

    csv_file.close()
    print csv_file.name, " complete. Pausing for 5 seconds."
    time.sleep(5)