from sys import stdin
from datetime import datetime
import csv


startTime = datetime.now()
OUTPUT_FILENAME = 'speed_log_%s.csv' % str(startTime)
print('Type speed and press [enter] to log it.  Type "!" to save and exit.')


with open(OUTPUT_FILENAME, 'w') as f:
    w = csv.writer(f)
    w.writerow(['timestamp', 'speed', 'count', 'duration'])
    count = 0

    while(True):
        line = stdin.readline()
        if('!' in line):
            break
        
        try:
            speed = line
            timeStamp = datetime.now()
            count += 1
            duration = timeStamp - startTime
            w.writerow([timeStamp,speed,count,duration])
            print ('Recording duration: %s' % str(duration))
            print ('Speed: %s' % str(speed).rstrip('\n'))
            print ('Count: %d' % count)
        except:
            print('Invalid input')
